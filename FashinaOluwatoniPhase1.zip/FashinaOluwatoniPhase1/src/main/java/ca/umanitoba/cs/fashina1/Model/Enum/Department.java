package ca.umanitoba.cs.fashina1.Model.Enum;
/* These are the various departments that might use or be
 * related to library services and resources.
 */
public enum Department {
    Science,
    Art,
    Recreation,
    Journalism,
    Business,
    Hospitality
}
